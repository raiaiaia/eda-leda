package forma;

public interface FormaInterface {
    
    double calculaArea();
}
